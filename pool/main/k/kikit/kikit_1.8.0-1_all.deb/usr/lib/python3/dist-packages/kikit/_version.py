def get_versions():
    return {'version': '1.8.0-1'}
