def get_versions():
    return {'version': '1.3.0-7'}
