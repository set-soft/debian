def get_versions():
    return {'version': '1.6.0-2'}
