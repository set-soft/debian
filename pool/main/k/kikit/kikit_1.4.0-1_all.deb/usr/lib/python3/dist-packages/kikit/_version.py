def get_versions():
    return {'version': '1.4.0-1'}
