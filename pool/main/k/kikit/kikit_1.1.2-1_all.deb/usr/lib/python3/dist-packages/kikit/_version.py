def get_versions():
    return {'version': '1.1.2-1'}
