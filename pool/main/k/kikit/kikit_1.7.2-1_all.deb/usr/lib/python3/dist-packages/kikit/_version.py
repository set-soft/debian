def get_versions():
    return {'version': '1.7.2-1'}
