This directory contains:

- OpenSCAD for Python  https://github.com/SolidCode/SolidPython
  (c) 2009 Philipp Tiefenbacher
  (c) 2011-2019 Evan Jones
  LGPL 2.1
- Euclid3
  (c) 2006 Alex Holkner
  LGPL 2.1

Why here?

They are rare dependencies, i.e. not found on Debian stable.
OpenSCAD also depends on other things, not really needed by KiKit.
In particular PyPNG, another rare dependency.
