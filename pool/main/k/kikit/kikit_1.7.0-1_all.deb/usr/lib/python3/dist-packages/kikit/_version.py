def get_versions():
    return {'version': '1.7.0-1'}
