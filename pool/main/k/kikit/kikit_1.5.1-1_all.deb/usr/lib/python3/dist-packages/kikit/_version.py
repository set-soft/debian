def get_versions():
    return {'version': '1.5.1-1'}
