def get_versions():
    return {'version': '1.7.1-1'}
