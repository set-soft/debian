__author__ = 'XESS Corporation'
__email__ = 'info@xess.com'
__version__ = '1.1.20'
__build__ = '43fca3b-2025-03-27'
