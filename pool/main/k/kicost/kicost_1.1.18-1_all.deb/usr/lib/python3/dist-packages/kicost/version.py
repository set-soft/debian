__author__ = 'XESS Corporation'
__email__ = 'info@xess.com'
__version__ = '1.1.18'
__build__ = '197a61d-2023-06-22'
