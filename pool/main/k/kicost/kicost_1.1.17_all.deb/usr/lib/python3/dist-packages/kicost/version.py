__author__ = 'XESS Corporation'
__email__ = 'info@xess.com'
__version__ = '1.1.17'
__build__ = 'd70ad0d-2023-05-15'
