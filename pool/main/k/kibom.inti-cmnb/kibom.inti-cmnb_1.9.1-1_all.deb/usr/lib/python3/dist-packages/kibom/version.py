# -*- coding: utf-8 -*-

KIBOM_VERSION = "1.9.1"
