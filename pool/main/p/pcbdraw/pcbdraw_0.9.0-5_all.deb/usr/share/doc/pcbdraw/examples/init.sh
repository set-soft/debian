#!/usr/bin/env bash

# Clone example board
rm -rf ArduinoLearningKitStarter
git clone https://github.com/RoboticsBrno/ArduinoLearningKitStarter.git
cd ArduinoLearningKitStarter
git checkout v3.1
