def get_versions():
    return {'version': '0.4.1-1'}
